using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using UnityEngine.Events;

public class Pipe : Agent
{
    Rigidbody rBody;
    void Start()
    {
        rBody = GetComponent<Rigidbody>();
    }

    public Transform Target;

    public override void OnEpisodeBegin()
    {
        float distanceToTarget = Vector3.Distance(this.transform.position, Target.position);

        if (distanceToTarget < 1.1f)
        {
         // Learning Mode
            this.transform.position = new Vector3(6f, 2f, -10f);
            //Destroy(this);
        }
           
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.name == "Cube")
        this.transform.position = new Vector3(6f, 2f, -10f);
        AddReward(-1.0f);
        EndEpisode();

        if (collision.gameObject.name == "Obs")
            this.transform.position = new Vector3(6f, 2f, -10f);
        AddReward(-1.0f);
        EndEpisode();
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // Distance between Agent and Target
        Vector3 relativePosition = Target.position - this.transform.position;

        // Obervation
        sensor.AddObservation(relativePosition.x);
        sensor.AddObservation(relativePosition.y);
        sensor.AddObservation(relativePosition.z);
    }

    const int X_Plus = 1;
    const int X_Minus = 2;
    const int Y_Plus = 3;
    const int Y_Minus = 4;
    const int Z_Plus = 5;
    const int Z_Minus = 6;


    private int previousAction = -1;
    private float previousDistance = float.MaxValue;

    public override void OnActionReceived(float[] vectorAction)
    {
        int action = Mathf.FloorToInt(vectorAction[0]);
        
        if (action == 1)
        {
            rBody.MovePosition(this.transform.position + new Vector3(0.5f, 0f, 0f));
        }

        if (action == 2)
        {
            rBody.MovePosition(this.transform.position + new Vector3(-0.5f, 0f, 0f));
        }

        if (action == 3)
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, 0.5f, 0f));
        }

        if (action == 4)
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, -0.5f, 0f));
        }

        if (action == 5)
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, 0f, 0.5f));
        }

        if (action == 6)
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, 0f, -0.5f));
        }

        // Rewards
        float distanceToTarget = Vector3.Distance(this.transform.localPosition, Target.localPosition);

        // Reached target
        if (distanceToTarget < 1.1f)
        {
            AddReward(5.0f);
            //Debug.Log(GetCumulativeReward());
            EndEpisode();
        }

        // Getting closer to Target
        if (distanceToTarget < previousDistance)
        {
            AddReward(0.1f);
        }

        //������ ���� ���� ����
        if (action != previousAction && previousAction != -1)
        {
            Debug.Log(action);
            AddReward(-0.1f);
        }
        previousDistance = distanceToTarget;
        previousAction = action;

        Debug.Log(GetCumulativeReward());

    }

    public override void Heuristic(float[] actionsOut)
    {

        if (Input.GetKey(KeyCode.D))
        {
            rBody.MovePosition(this.transform.position + new Vector3(0.5f, 0f, 0f));
        }
        if (Input.GetKey(KeyCode.A))
        {
            rBody.MovePosition(this.transform.position + new Vector3(-0.5f, 0f, 0f));
        }
        if (Input.GetKey(KeyCode.Q))
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, 0.5f, 0f));
        }
        if (Input.GetKey(KeyCode.E))
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, -0.5f, 0f));
        }
        if (Input.GetKey(KeyCode.W))
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, 0f, 0.5f));
        }
        if (Input.GetKey(KeyCode.S))
        {
            rBody.MovePosition(this.transform.position + new Vector3(0f, 0f, -0.5f));
        }
    }
}


// Alternative Action Mode
/*
var action = Mathf.FloorToInt(vectorAction[0]);

var targetPos = this.transform.position;
switch (action)
{
    case X_Plus:
        rBody.MovePosition(this.transform.position + new Vector3(0.5f, 0f, 0f));
        break;
    case X_Minus:
        rBody.MovePosition(this.transform.position + new Vector3(-0.5f, 0f, 0f));
        break;
    case Y_Plus:
        rBody.MovePosition(this.transform.position + new Vector3(0f, 0.5f, 0f));
        break;
    case Y_Minus:
        rBody.MovePosition(this.transform.position + new Vector3(0f, -0.5f, 0f));
        break;
    case Z_Plus:
        rBody.MovePosition(this.transform.position + new Vector3(0f, 0f, 0.5f));
        break;
    case Z_Minus:
        rBody.MovePosition(this.transform.position + new Vector3(0f, 0f, -0.5f));
        break;
}
*/
